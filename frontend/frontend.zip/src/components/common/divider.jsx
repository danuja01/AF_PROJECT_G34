const Divider = () => {
  return <div className="w-full h-[0.75px] bg-nav-links-unselected opacity-20 relative z-[2]" />
}

export default Divider
